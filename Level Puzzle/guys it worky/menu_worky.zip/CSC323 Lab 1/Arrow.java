import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


class Arrow
{
    //Variables
    int xPos, yPos;
    String direction;

    //Constructor sets variables
    public Arrow(int xPos, int yPos, String direction)
    {
        this.xPos = xPos;
        this.yPos = yPos;
        this.direction = direction;
    }

}

